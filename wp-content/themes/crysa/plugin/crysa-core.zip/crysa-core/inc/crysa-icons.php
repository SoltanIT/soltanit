<?php

// Flat icons
function crysa_flaticons() {
    return [
'flaticon-cloud'=>'flaticon-cloud',

'flaticon-support' => 'flaticon-support',

'flaticon-project-management'=>'flaticon-project-management',

'flaticon-technology'=>'flaticon-technology',

'flaticon-data-management'=>'flaticon-data-management',

'flaticon-innovation'=>'flaticon-innovation',

'flaticon-technology-1'=>'flaticon-technology-1',

'flaticon-technology-2'=>'flaticon-technology-2',

'flaticon-nanotechnology'=>'flaticon-nanotechnology',

'flaticon-artificial-intelligence'=>'flaticon-artificial-intelligence',

'flaticon-healthcare'=>'flaticon-healthcare',

'flaticon-technology-3'=>'flaticon-technology-3',

'flaticon-technology-4'=>'flaticon-technology-4',

'flaticon-dashboard'=>'flaticon-dashboard',

'flaticon-tech-service'=>'flaticon-tech-service',

'flaticon-creativity'=>'flaticon-creativity',

'flaticon-car'=>'flaticon-car',

'flaticon-data-processing'=>'flaticon-data-processing',

'flaticon-industrial'=>'flaticon-industrial',

'flaticon-mail'=>'flaticon-mail',

'flaticon-cloud-service'=>'flaticon-cloud-service',

'flaticon-wallet'=>'flaticon-wallet',

'flaticon-internet-connection'=>'flaticon-internet-connection',

'flaticon-mobile-banking'=>'flaticon-mobile-banking',

'flaticon-gadget'=>'flaticon-gadget',

'flaticon-innovation-1'=>'flaticon-innovation-1',

'flaticon-medical-symbol'=>'flaticon-medical-symbol',

'flaticon-virtual-reality-glasses'=>'flaticon-virtual-reality-glasses',

'flaticon-satellite'=>'flaticon-satellite',

'flaticon-mouse'=>'flaticon-mouse',

'flaticon-humidifier'=>'flaticon-humidifier',

'flaticon-autonomous-car'=>'flaticon-autonomous-car',

'flaticon-brain'=>'flaticon-brain',

'flaticon-heart-condition'=>'flaticon-heart-condition',

'flaticon-conveyor'=>'flaticon-conveyor',

'flaticon-global-network'=>'flaticon-global-network',

'flaticon-television'=>'flaticon-television',

'flaticon-internet-of-things'=>'flaticon-internet-of-things',

'flaticon-innovation-2'=>'flaticon-innovation-2',

'flaticon-artificial-intelligence-1'=>'flaticon-artificial-intelligence-1',

'flaticon-virtual-reality'=>'flaticon-virtual-reality',

'flaticon-observatory'=>'flaticon-observatory',

'flaticon-cloud-computing'=>'flaticon-cloud-computing',

'flaticon-transformation'=>'flaticon-transformation',

'flaticon-smartwatch'=>'flaticon-smartwatch',

'flaticon-server'=>'flaticon-server',

'flaticon-woman'=>'flaticon-woman',

'flaticon-startup'=>'flaticon-startup',

'flaticon-research'=>'flaticon-research',

'flaticon-smart-house'=>'flaticon-smart-house',

'flaticon-smart-city'=>'flaticon-smart-city',

'flaticon-sensor'=>'flaticon-sensor',

'flaticon-protection'=>'flaticon-protection',

'flaticon-tv'=>'flaticon-tv',

'flaticon-cloud-sync'=>'flaticon-cloud-sync',

'flaticon-machine'=>'flaticon-machine',

'flaticon-augmented-reality'=>'flaticon-augmented-reality',

'flaticon-life-insurance'=>'flaticon-life-insurance',

'flaticon-infrastructure'=>'flaticon-infrastructure',

'flaticon-food-delivery'=>'flaticon-food-delivery',

'flaticon-planet-earth'=>'flaticon-planet-earth',

'flaticon-videogame'=>'flaticon-videogame',

'flaticon-qr-code'=>'flaticon-qr-code',

'flaticon-game-control'=>'flaticon-game-control',

'flaticon-stock-market'=>'flaticon-stock-market',

'flaticon-farm'=>'flaticon-farm',

'flaticon-phone-call'=>'flaticon-phone-call',

'flaticon-smart-home'=>'flaticon-smart-home',

'flaticon-infrastructure-1'=>'flaticon-infrastructure-1',

'flaticon-folder'=>'flaticon-folder',

'flaticon-mobile-phone'=>'flaticon-mobile-phone',

'flaticon-chatbot'=>'flaticon-chatbot',

'flaticon-developer'=>'flaticon-developer',

'flaticon-voice-assistant'=>'flaticon-voice-assistant',

'flaticon-laptop'=>'flaticon-laptop',

'flaticon-app'=>'flaticon-app',

'flaticon-smart-car'=>'flaticon-smart-car',

'flaticon-printer'=>'flaticon-printer',

'flaticon-vaccum-cleaner'=>'flaticon-vaccum-cleaner',

'flaticon-data-management-1'=>'flaticon-data-management-1',

'flaticon-cyber-security'=>'flaticon-cyber-security',

'flaticon-ar-glasses'=>'flaticon-ar-glasses',

'flaticon-promotion'=>'flaticon-promotion',

'flaticon-customer-support'=>'flaticon-customer-support',

'flaticon-robot'=>'flaticon-robot',

'flaticon-vr'=>'flaticon-vr',

'flaticon-cloud-computing-1'=>'flaticon-cloud-computing-1',

'flaticon-chatbot-1'=>'flaticon-chatbot-1',

'flaticon-servers'=>'flaticon-servers',

'flaticon-database-storage'=>'flaticon-database-storage',

'flaticon-technology-5'=>'flaticon-technology-5',

'flaticon-battery'=>'flaticon-battery',

'flaticon-nanocrysa'=>'flaticon-nanocrysa',

'flaticon-humanoid'=>'flaticon-humanoid',

'flaticon-laser-cutting-machine'=>'flaticon-laser-cutting-machine',

'flaticon-printer-1'=>'flaticon-printer-1',

'flaticon-vr-goggles'=>'flaticon-vr-goggles',

'flaticon-sensor-1'=>'flaticon-sensor-1',

'flaticon-hand-and-trackpad'=>'flaticon-hand-and-trackpad',

'flaticon-idea'=>'flaticon-idea',

'flaticon-camera-remote-control'=>'flaticon-camera-remote-control',

'flaticon-renewable-energy'=>'flaticon-renewable-energy',

'flaticon-weather'=>'flaticon-weather',

'flaticon-smartphone'=>'flaticon-smartphone',

'flaticon-touch-screen-with-hand'=>'flaticon-touch-screen-with-hand',

'flaticon-technology-6'=>'flaticon-technology-6',

'flaticon-facial-recognition'=>'flaticon-facial-recognition',

'flaticon-technology-7'=>'flaticon-technology-7',

'flaticon-server-1'=>'flaticon-server-1',

'flaticon-vr-technology'=>'flaticon-vr-technology',

'flaticon-delivery-truck'=>'flaticon-delivery-truck',

'flaticon-software'=>'flaticon-software',

'flaticon-technology-podcast'=>'flaticon-technology-podcast',

'flaticon-technology-products'=>'flaticon-technology-products',

'flaticon-360'=>'flaticon-360',

'flaticon-goggles'=>'flaticon-goggles',

'flaticon-startup-1'=>'flaticon-startup-1',

'flaticon-certificate'=>'flaticon-certificate',

'flaticon-certificate-1'=>'flaticon-certificate-1',

'flaticon-certificate-2'=>'flaticon-certificate-2',

'flaticon-medal'=>'flaticon-medal',

'flaticon-award'=>'flaticon-award',

'flaticon-award-1'=>'flaticon-award-1',

'flaticon-cloud-1'=>'flaticon-cloud-1',

'flaticon-cloud-data'=>'flaticon-cloud-data',

'flaticon-cloud-data-1'=>'flaticon-cloud-data-1',

'flaticon-cloud-network'=>'flaticon-cloud-network',

'flaticon-migration'=>'flaticon-migration',

'flaticon-security'=>'flaticon-security',

'flaticon-shield'=>'flaticon-shield',

'flaticon-data-security'=>'flaticon-data-security',

'flaticon-guard'=>'flaticon-guard',

'flaticon-data'=>'flaticon-data',

'flaticon-backup'=>'flaticon-backup',

'flaticon-data-recovery'=>'flaticon-data-recovery',

'flaticon-data-recovery-1'=>'flaticon-data-recovery-1',

'flaticon-cloud-server'=>'flaticon-cloud-server',

'flaticon-database-storage-1'=>'flaticon-database-storage-1',

'flaticon-select'=>'flaticon-select',

'flaticon-select-1'=>'flaticon-select-1',

'flaticon-touchscreen'=>'flaticon-touchscreen',

'flaticon-interview'=>'flaticon-interview',

'flaticon-interview-1'=>'flaticon-interview-1',

'flaticon-online-meeting'=>'flaticon-online-meeting',

'flaticon-target'=>'flaticon-target',

'flaticon-plan'=>'flaticon-plan',

'flaticon-receipts'=>'flaticon-receipts',

'flaticon-confirmation'=>'flaticon-confirmation',

'flaticon-confirmation-1'=>'flaticon-confirmation-1',

'flaticon-confirmation-2'=>'flaticon-confirmation-2',

'flaticon-firewall'=>'flaticon-firewall',

'flaticon-firewall-1'=>'flaticon-firewall-1',

'flaticon-firewall-2'=>'flaticon-firewall-2',

'flaticon-firewall-3'=>'flaticon-firewall-3',

'flaticon-firewall-4'=>'flaticon-firewall-4',

'flaticon-firewall-5'=>'flaticon-firewall-5',

'flaticon-firewall-6'=>'flaticon-firewall-6',

'flaticon-risk'=>'flaticon-risk',

'flaticon-risk-management'=>'flaticon-risk-management',

'flaticon-checked'=>'flaticon-checked',

'flaticon-check'=>'flaticon-check',

'flaticon-shield-1'=>'flaticon-shield-1',

'flaticon-check-1'=>'flaticon-check-1',

'flaticon-right-arrow-angle'=>'flaticon-right-arrow-angle',

'flaticon-down'=>'flaticon-down',

'flaticon-big'=>'flaticon-big',

'flaticon-right-arrow'=>'flaticon-right-arrow',

'flaticon-down-arrow'=>'flaticon-down-arrow',

'flaticon-right-arrow-1'=>'flaticon-right-arrow-1',

];

}

function crysa_include_flaticons() {
    return array_keys(crysa_flaticons());
}
?>